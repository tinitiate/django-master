from django.apps import AppConfig


class AppDbRoutingConfig(AppConfig):
    name = 'app_db_routing'
