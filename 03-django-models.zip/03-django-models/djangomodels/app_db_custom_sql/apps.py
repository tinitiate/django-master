from django.apps import AppConfig


class AppDbCustomSqlConfig(AppConfig):
    name = 'app_db_custom_sql'
