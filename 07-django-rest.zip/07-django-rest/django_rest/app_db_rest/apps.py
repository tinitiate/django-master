from django.apps import AppConfig


class AppDbRestConfig(AppConfig):
    name = 'app_db_rest'
