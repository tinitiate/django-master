from django.apps import AppConfig


class AppUrlsViewsConfig(AppConfig):
    name = 'app_urls_views'
